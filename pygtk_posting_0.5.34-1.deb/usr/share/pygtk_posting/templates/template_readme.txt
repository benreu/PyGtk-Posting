Do not delete any single files in this folder! If you delete any of these templates and PyGtk Posting quits working, it is your own fault!

If you have messed up the templates in the folder /home/your_user_name/.config/posting/templates and wish to start over, delete the whole templates folder and restart Posting and a fresh templates folder will be copied in. But do not delete the installed templated folder in /usr/share/pygtk_posting.

I have tried to name the templates according to the job they do. If you are not sure where they belong, put some special text in them you will recgonize, and then open different template buttons/windows until it makes sense. And then if you have suggestions, feel free to zip me some encouragement/criticism pygtk.posting@gmail.com.

If you set a default printer to a template under File>Printer Settings this will be the printer that gets auto printed to. Thanks to Eli Sauder for discovering this.


